# Total Terminal Puppet Module for Boxen
[![Build
Status](https://travis-ci.org/andrzejsliwa/puppet-totalterminal.png?branch=master)](https://travis-ci.org/andrzejsliwa/puppet-totalterminal)

Install [Total Terminal](http://totalterminal.binaryage.com), a system-wide terminal available on a hot-key

## Usage

```puppet
include totalterminal
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
